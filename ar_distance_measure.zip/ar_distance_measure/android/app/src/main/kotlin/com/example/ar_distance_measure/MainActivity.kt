package com.example.ar_distance_measure

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
