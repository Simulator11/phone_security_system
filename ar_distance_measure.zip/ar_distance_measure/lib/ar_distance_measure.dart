import 'package:ar_flutter_plugin_updated/managers/ar_anchor_manager.dart';
import 'package:ar_flutter_plugin_updated/managers/ar_location_manager.dart';
import 'package:ar_flutter_plugin_updated/managers/ar_object_manager.dart';
import 'package:ar_flutter_plugin_updated/managers/ar_session_manager.dart';
import 'package:flutter/material.dart';
import 'package:ar_flutter_plugin_updated/ar_flutter_plugin.dart';
import 'package:vector_math/vector_math_64.dart' as vector;

class ARDistanceMeasure extends StatefulWidget {
  @override
  _ARDistanceMeasureState createState() => _ARDistanceMeasureState();
}

class _ARDistanceMeasureState extends State<ARDistanceMeasure> {
  ARSessionManager? arSessionManager;
  ARObjectManager? arObjectManager;
  ARAnchorManager? arAnchorManager;
  vector.Vector3? firstPoint;
  vector.Vector3? secondPoint;
  double? distance;

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        ARView(onARViewCreated: onARViewCreated),
        if (distance != null)
          Positioned(
            bottom: 150,
            left: 20,
            child: Container(
              decoration: BoxDecoration(
                color: Colors.black54,
                borderRadius: BorderRadius.circular(8),
              ),
              padding: const EdgeInsets.all(10),
              child: Text(
                'Distance: ${distance!.toStringAsFixed(2)} m',
                style: const TextStyle(color: Colors.white, fontSize: 18),
              ),
            ),
          ),
        Positioned(
          bottom: 40,
          right: 20,
          child: FloatingActionButton.extended(
            label: Text(firstPoint == null ? 'Set First Point' : 'Set Second Point'),
            icon: const Icon(Icons.adjust),
            backgroundColor: Colors.deepPurpleAccent,
            onPressed: () => setPointFromCamera(),
          ),
        ),
      ],
    );
  }

  /// **AR View Created Callback**
  void onARViewCreated(
      ARSessionManager sessionManager,
      ARObjectManager objectManager,
      ARAnchorManager anchorManager,
      ARLocationManager locationManager) {
    arSessionManager = sessionManager;
    arObjectManager = objectManager;
    arAnchorManager = anchorManager;

    // Initialize AR Session
    arSessionManager?.onInitialize(
      showFeaturePoints: true,
      showPlanes: true,
      customPlaneTexturePath: "images/triangle.png",
      showWorldOrigin: true,
    );
    arObjectManager?.onInitialize();

    // Listen for taps to set points
    arSessionManager?.onPlaneOrPointTap = (hitResults) {
      if (hitResults.isNotEmpty) {
        var worldTransform = hitResults.first.worldTransform;
        vector.Vector3 point = worldTransform.getTranslation();
        confirmPointSelection(point);
      }
    };
  }

  /// **Prompt User for Point Confirmation**
  void confirmPointSelection(vector.Vector3 point) {
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text("Confirm Point"),
        content: const Text("Do you want to set this point?"),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(context).pop(),
            child: const Text("Cancel"),
          ),
          ElevatedButton(
            onPressed: () {
              setPoint(point);
              Navigator.of(context).pop();
            },
            child: const Text("Confirm"),
          ),
        ],
      ),
    );
  }

  /// **Sets the first or second point for distance measurement**
  void setPoint(vector.Vector3 point) {
    setState(() {
      if (firstPoint == null) {
        firstPoint = point;
        showSnackbar("First Point Set");
      } else if (secondPoint == null) {
        secondPoint = point;
        calculateDistance();
        showSnackbar("Second Point Set");
      } else {
        firstPoint = point;
        secondPoint = null;
        distance = null;
        showSnackbar("First Point Reset");
      }
    });
  }

  /// **Show Snackbar for User Feedback**
  void showSnackbar(String message) {
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(message),
        duration: const Duration(seconds: 2),
      ),
    );
  }

  /// **Sets the point from the camera position**
  void setPointFromCamera() async {
    var cameraPose = await arSessionManager?.getCameraPose();
    if (cameraPose != null) {
      vector.Vector3 point = vector.Vector3(
        cameraPose.storage[12], // X
        cameraPose.storage[13], // Y
        cameraPose.storage[14], // Z
      );
      confirmPointSelection(point);
    }
  }

  /// **Calculates the Euclidean distance between two points**
  void calculateDistance() {
    if (firstPoint != null && secondPoint != null) {
      distance = (firstPoint! - secondPoint!).length;
      setState(() {});
    }
  }

  @override
  void dispose() {
    arSessionManager?.dispose();
    super.dispose();
  }
}
