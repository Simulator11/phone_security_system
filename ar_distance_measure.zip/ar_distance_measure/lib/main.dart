import 'package:flutter/material.dart';
import 'ar_distance_measure.dart';

void main() => runApp(ARDistanceApp());

class ARDistanceApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      home: Scaffold(
        appBar: AppBar(
          title: const Text("AR Distance Measurement"),
          backgroundColor: Colors.deepPurpleAccent,
          centerTitle: true,
        ),
        body: ARDistanceMeasure(),
      ),
    );
  }
}
